# CS 245 (Fall 2018) Practice Assignment 09

See assignment details on Canvas.
